DROP TABLE public.activities;
DROP TABLE public.activity_types;
DROP TABLE public.recommendations;
DROP TABLE public.videos;
DROP TABLE public.friends;
DROP TABLE public.users;
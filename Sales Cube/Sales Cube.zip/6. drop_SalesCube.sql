DROP TABLE public.sales;
DROP TABLE public.customers;
DROP TABLE public.products;
DROP TABLE public.categories;
DROP TABLE public.states;